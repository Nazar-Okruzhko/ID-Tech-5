++===vtex.exe - A literal virtualtexture extractor===++
How to use vtex.exe? 
1. Download Windows 7 x64 ISO
2. Downlaod VMWare/Virtualbox
3. Install Windows 7 virtualmachine enable shared folder to share files across VM and your main OS
4. Install VCRedist all in one pack for your Windows VM
5. Copy this foolder into Windows VM [virtualtextures/]
6. Copy all your virtualtextures here into this folder on VM [virtualtextures/virtualtextures/]
7. Run this command: vtex.exe [source file, path to your .pages file] D:\ [destination folder, whetever disk that has the most storage]
Remember, no spaces or "-" symbols in your path, also disable ASLR exploit protection: [MoveImages=0]